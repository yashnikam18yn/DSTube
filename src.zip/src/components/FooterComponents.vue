<template>
    <footer class="footer">
      <div class="container">
        <p>&copy; @2024 Yash Nikam. All rights reserved.</p>
      </div>
    </footer>
  </template>
  
  <script setup>
  </script>
  
  <style scoped>
  .footer {
    position: fixed;
    bottom: 0;
    width: 100%;
    background-color: #333;
    color: white;
    text-align: center;
    padding: 10px 0;
  }
  
  .container {
    display: flex;
    justify-content: center;
    align-items: center;
  }
  </style>
  