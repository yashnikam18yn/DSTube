<template>
<h2>Hello Yash</h2>
</template>

<script setup>

</script>

<style scoped>

</style>