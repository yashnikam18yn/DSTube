<template>
   
    <Card/>
</template>
  
  <script setup>
  import Card from './Card.vue'
  </script>
  
  <style scoped>
  
  
  </style>
  